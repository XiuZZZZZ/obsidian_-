


var kFYDTemplate = {
    "small":{
        "height":125,
        "width":90,
        "printConent":[
            //第一行：床号，姓名，住院号，
            {
                TypeCode:"OneLineByCode", //打印模式：一行，多个内容
                PrintStartDirection:1,
                LineHeight:10,
                PrintLineCode:[
                    {"code":"bedCode","text":"床号","width":20},
                    {"code":"name","text":"姓名","width":20},
                    {"code":"medical","text":"住院号","width":20}
                ],
                PrintLineHeight:20
            },
            //第二行：日期+"口服"
            {
                TypeCode:"OneLineByCode", //打印模式：一个内容
                PrintStartDirection:-1,
                LineHeight:10,
                PrintLineCode:[
                    {"code":"","text":"口服","width":40},
                    {"code":"printDateTimeL","text":"11","width":20},
                ]
            },
            //第三行：晚上几点， 核对人， 执行人
            {
                TypeCode:"OneLineByStr", //打印模式：一个内容
                PrintStartDirection:"right",
                PrintLineCode:[
                    {"code":"printDateTimeL","text":"","width":20},
                    {"code":"","text":"口服","width":20},
                ]
            },
            //第四行：两排医嘱
            {
                TypeCode:"OrderContent",
                PrintLineCode:[
                    {"code":"orderDate","text":"","width":20},
                    {"code":"","text":"核对人","width":20},
                    {"code":"","text":"执行人","width":20},
                ],
                PrintOrderWifth:10,
                PrintOrderOneCode:[
                    {"code":"orderDesc","text":"","width":20},
                ],
                PrintOrderTwoCode:[
                    {"code":"otherInfo","text":"","width":20},
                ]
            },
            //第五行：晚上几点， 核对人， 执行人
            {
                TypeCode:"OneLineByStr", //打印模式：一个内容
                PrintStartDirection:"right",
                PrintLineCode:[
                    {"code":"printDateTimeL","text":"","width":20},
                    {"code":"","text":"口服","width":20},
                ]
            },
            //第六行：两排医嘱
            {
                TypeCode:"OrderContent",
                PrintLineCode:[
                    {"code":"orderDate","text":"","width":20},
                    {"code":"","text":"核对人","width":20},
                    {"code":"","text":"执行人","width":20},
                ],
                PrintOrderWifth:10,
                PrintOrderOneCode:[
                    {"code":"orderDesc","text":"","width":20},
                ],
                PrintOrderTwoCode:[
                    {"code":"otherInfo","text":"","width":20},
                ]
            }
        ]
    }
}